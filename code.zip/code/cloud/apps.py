from django.apps import AppConfig


class CloudConfig(AppConfig):
    name = 'cloud'
